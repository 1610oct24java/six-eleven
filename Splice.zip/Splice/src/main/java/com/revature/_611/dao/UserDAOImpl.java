package com.revature._611.dao;

import com.revature._611.utils.HibernateUtil;

/**
 * 2016/12/01
 * User DAO Implementation for first sprint of Project 2: Splice Game. <br>
 * 
 * @author Ric Smith
 * @version 1.0
 */
public class UserDAOImpl implements UserDAO {

	private static HibernateUtil hu = new HibernateUtil();
	
	
}
