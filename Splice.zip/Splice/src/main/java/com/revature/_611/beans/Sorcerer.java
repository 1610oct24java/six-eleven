package com.revature._611.beans;

public class Sorcerer {
	
	private int vitality;

}
